import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { HashRouter, Routes, Route, Navigate } from "react-router-dom";
import { ErrorBoundary } from "react-error-boundary";
import { ROUTE_PATHS } from "@/lib/index";
import { AuthProvider, useAuth } from "@/hooks/useAuth";
import { LanguageProvider } from "@/hooks/useLanguage";
import { Layout } from "@/components/Layout";
import { NotificationPanel } from "@/components/NotificationPanel";
import Login from "@/pages/Login";
import Dashboard from "@/pages/Dashboard";
import SupervisorPortal from "@/pages/SupervisorPortal";
import WayplanPortal from "@/pages/WayplanPortal";
import DriverPortal from "@/pages/DriverPortal";
import WarehousePortal from "@/pages/WarehousePortal";
import DataEntryPortal from "@/pages/DataEntryPortal";
import CustomerService from "@/pages/CustomerService";
import MarketingPortal from "@/pages/MarketingPortal";
import HRPortal from "@/pages/HRPortal";
import FinancePortal from "@/pages/FinancePortal";
import MerchantPortal from "@/pages/MerchantPortal";
import CustomerPortal from "@/pages/CustomerPortal";
import CreateDelivery from "@/pages/CreateDelivery";
import Analytics from "@/pages/Analytics";
import Settings from "@/pages/Settings";
import QRCodeManagement from "@/pages/QRCodeManagement";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5,
      refetchOnWindowFocus: false,
      retry: 1,
    },
  },
});

function ErrorFallback({ error, resetErrorBoundary }: { error: Error; resetErrorBoundary: () => void }) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="max-w-md w-full p-8 bg-card rounded-lg border border-border shadow-lg">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-full bg-destructive/10 flex items-center justify-center">
            <svg className="w-6 h-6 text-destructive" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
          <div>
            <h2 className="text-lg font-semibold text-foreground">Application Error</h2>
            <p className="text-sm text-muted-foreground">Something went wrong</p>
          </div>
        </div>
        <div className="mb-6 p-4 bg-muted rounded-md">
          <p className="text-sm text-foreground font-mono break-all">{error.message}</p>
        </div>
        <button
          onClick={resetErrorBoundary}
          className="w-full px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors font-medium"
        >
          Try Again
        </button>
      </div>
    </div>
  );
}

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
}

function AppRoutes() {
  const { isAuthenticated } = useAuth();

  return (
    <Routes>
      <Route
        path="/login"
        element={isAuthenticated ? <Navigate to={ROUTE_PATHS.DASHBOARD} replace /> : <Login />}
      />
      <Route
        path="/*"
        element={
          <ProtectedRoute>
            <Layout>
              <Routes>
                <Route path={ROUTE_PATHS.DASHBOARD} element={<Dashboard />} />
                <Route path={ROUTE_PATHS.SUPERVISOR} element={<SupervisorPortal />} />
                <Route path="/supervisor/*" element={<SupervisorPortal />} />
                <Route path={ROUTE_PATHS.WAYPLAN} element={<WayplanPortal />} />
                <Route path="/wayplan/*" element={<WayplanPortal />} />
                <Route path={ROUTE_PATHS.DRIVER} element={<DriverPortal />} />
                <Route path="/driver/*" element={<DriverPortal />} />
                <Route path={ROUTE_PATHS.WAREHOUSE} element={<WarehousePortal />} />
                <Route path="/warehouse/*" element={<WarehousePortal />} />
                <Route path={ROUTE_PATHS.DATA_ENTRY} element={<DataEntryPortal />} />
                <Route path="/data-entry/*" element={<DataEntryPortal />} />
                <Route path={ROUTE_PATHS.CUSTOMER_SERVICE} element={<CustomerService />} />
                <Route path="/customer-service/*" element={<CustomerService />} />
                <Route path={ROUTE_PATHS.MARKETING} element={<MarketingPortal />} />
                <Route path="/marketing/*" element={<MarketingPortal />} />
                <Route path={ROUTE_PATHS.HR} element={<HRPortal />} />
                <Route path="/hr/*" element={<HRPortal />} />
                <Route path={ROUTE_PATHS.FINANCE} element={<FinancePortal />} />
                <Route path="/finance/*" element={<FinancePortal />} />
                <Route path={ROUTE_PATHS.MERCHANT} element={<MerchantPortal />} />
                <Route path="/merchant/*" element={<MerchantPortal />} />
                <Route path={ROUTE_PATHS.CUSTOMER} element={<CustomerPortal />} />
                <Route path="/customer/*" element={<CustomerPortal />} />
                <Route path={ROUTE_PATHS.CREATE_DELIVERY} element={<CreateDelivery />} />
                <Route path={ROUTE_PATHS.QR_CODE} element={<QRCodeManagement />} />
                <Route path={ROUTE_PATHS.ANALYTICS} element={<Analytics />} />
                <Route path="/analytics/*" element={<Analytics />} />
                <Route path={ROUTE_PATHS.SETTINGS} element={<Settings />} />
                <Route path="*" element={<Navigate to={ROUTE_PATHS.DASHBOARD} replace />} />
              </Routes>
              <NotificationPanel />
            </Layout>
          </ProtectedRoute>
        }
      />
    </Routes>
  );
}

const App = () => (
  <ErrorBoundary FallbackComponent={ErrorFallback} onReset={() => window.location.reload()}>
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <AuthProvider>
          <TooltipProvider>
            <Toaster />
            <Sonner />
            <HashRouter>
              <AppRoutes />
            </HashRouter>
          </TooltipProvider>
        </AuthProvider>
      </LanguageProvider>
    </QueryClientProvider>
  </ErrorBoundary>
);

export default App;