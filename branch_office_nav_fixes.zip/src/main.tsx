import { createRoot } from 'react-dom/client'
import App from './App.tsx'
import './index.css'
import { ErrorBoundary } from './components/ErrorBoundary'
import './styles/future-ui.css';
import './styles/ultra-ui-mobile.css';
import PublicApkDownloadPrompt from './components/PublicApkDownloadPrompt';

createRoot(document.getElementById("root")!).render(
    <ErrorBoundary>
      <><App /><PublicApkDownloadPrompt /></>
    </ErrorBoundary>
  );
