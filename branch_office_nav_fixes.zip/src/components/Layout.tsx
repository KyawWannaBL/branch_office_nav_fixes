import { useState } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Menu,
  X,
  Bell,
  User,
  LogOut,
  ChevronDown,
  LayoutDashboard,
  Users,
  Truck,
  Warehouse,
  Headphones,
  PlusCircle,
  BarChart3,
  Settings,
  ChevronRight,
  Package,
  MapPin,
  FileText,
  Clock,
  AlertCircle,
  Database,
  Route,
  Megaphone,
  UserCog,
  DollarSign,
  Store,
  ShoppingBag,
  Languages,
  QrCode,
  Building2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useAuth } from '@/hooks/useAuth';
import { useLanguage } from '@/hooks/useLanguage';
import { ROUTE_PATHS } from '@/lib/index';
import type { RoutePath } from '@/lib/index';
import { cn } from '@/lib/utils';

interface NavItem {
  path: RoutePath;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string;
  subItems?: {
    label: string;
    path: string;
    icon: React.ComponentType<{ className?: string }>;
  }[];
}

const NAV_ITEMS: NavItem[] = [
  { 
    path: ROUTE_PATHS.DASHBOARD, 
    label: 'nav.dashboard', 
    icon: LayoutDashboard,
  },
  { 
    path: ROUTE_PATHS.SUPERVISOR, 
    label: 'nav.supervisor', 
    icon: Users,
    subItems: [
      { label: 'nav.overview', path: '/supervisor/overview', icon: Users },
      { label: 'nav.queueManagement', path: '/supervisor/queue', icon: Package },
      { label: 'nav.fleetMobility', path: '/supervisor/fleet', icon: Truck },
      { label: 'nav.exceptions', path: '/supervisor/exceptions', icon: AlertCircle },
    ]
  },
  { 
    path: ROUTE_PATHS.WAYPLAN, 
    label: 'nav.wayplan', 
    icon: Route,
    subItems: [
      { label: 'nav.routeOptimization', path: '/wayplan/optimize', icon: Route },
      { label: 'nav.manifests', path: '/wayplan/manifests', icon: FileText },
      { label: 'nav.vehicleAssignment', path: '/wayplan/vehicles', icon: Truck },
      { label: 'Way Management / လမ်းကြောင်းစီမံခန့်ခွဲမှု', path: '/wayplan/ways', icon: Package },
      { label: 'Waybill Print / waybill ပုံနှိပ်ရန်', path: '/wayplan/waybills', icon: FileText },
    ]
  },
  { 
    path: ROUTE_PATHS.DRIVER, 
    label: 'nav.driver', 
    icon: Truck,
    subItems: [
      { label: 'nav.activeJobs', path: '/driver/jobs', icon: Package },
      { label: 'nav.route', path: '/driver/route', icon: MapPin },
      { label: 'nav.proofDelivery', path: '/driver/proof', icon: FileText },
      { label: 'nav.earnings', path: '/driver/earnings', icon: Clock },
    ]
  },
  { 
    path: ROUTE_PATHS.WAREHOUSE, 
    label: 'nav.warehouse', 
    icon: Warehouse,
    subItems: [
      { label: 'nav.inbound', path: '/warehouse/inbound', icon: Package },
      { label: 'nav.sorting', path: '/warehouse/sorting', icon: LayoutDashboard },
      { label: 'nav.dispatch', path: '/warehouse/dispatch', icon: Truck },
    ]
  },
  { 
    path: ROUTE_PATHS.DATA_ENTRY, 
    label: 'nav.dataEntry', 
    icon: Database,
    subItems: [
      { label: 'nav.bulkUpload', path: '/data-entry/bulk', icon: Database },
      { label: 'nav.manualEntry', path: '/data-entry/manual', icon: FileText },
      { label: 'nav.templates', path: '/data-entry/templates', icon: FileText },
      { label: 'nav.records', path: '/data-entry/records', icon: Database },
    ]
  },
  { 
    path: ROUTE_PATHS.CUSTOMER_SERVICE, 
    label: 'nav.customerService', 
    icon: Headphones,
    badge: '3',
    subItems: [
      { label: 'nav.requests', path: '/customer-service/requests', icon: FileText },
      { label: 'nav.liveChat', path: '/customer-service/chat', icon: Headphones },
    ]
  },
  { 
    path: ROUTE_PATHS.MARKETING, 
    label: 'nav.marketing', 
    icon: Megaphone,
    subItems: [
      { label: 'nav.campaigns', path: '/marketing/campaigns', icon: Megaphone },
      { label: 'nav.merchants', path: '/marketing/merchants', icon: Users },
      { label: 'nav.overview', path: '/marketing/overview', icon: BarChart3 },
    ]
  },
  { 
    path: ROUTE_PATHS.HR, 
    label: 'nav.hr', 
    icon: UserCog,
    subItems: [
      { label: 'nav.employees', path: '/hr/employees', icon: Users },
      { label: 'nav.attendance', path: '/hr/attendance', icon: Clock },
      { label: 'nav.leaveRequests', path: '/hr/leave', icon: FileText },
    ]
  },
  { 
    path: ROUTE_PATHS.FINANCE, 
    label: 'nav.finance', 
    icon: DollarSign,
    subItems: [
      { label: 'nav.transactions', path: '/finance/transactions', icon: DollarSign },
      { label: 'nav.codCollections', path: '/finance/cod', icon: Package },
      { label: 'nav.invoices', path: '/finance/invoices', icon: FileText },
    ]
  },
  { 
    path: ROUTE_PATHS.MERCHANT, 
    label: 'nav.merchant', 
    icon: Store,
    subItems: [
      { label: 'nav.myDeliveries', path: '/merchant/deliveries', icon: Package },
      { label: 'nav.createShipment', path: '/merchant/create', icon: PlusCircle },
      { label: 'nav.reports', path: '/merchant/reports', icon: BarChart3 },
    ]
  },
  { 
    path: ROUTE_PATHS.CUSTOMER, 
    label: 'nav.customer', 
    icon: ShoppingBag,
    subItems: [
      { label: 'nav.trackShipment', path: '/customer/track', icon: MapPin },
      { label: 'nav.myOrders', path: '/customer/orders', icon: Package },
      { label: 'nav.support', path: '/customer/support', icon: Headphones },
    ]
  },
  { 
    path: ROUTE_PATHS.CREATE_DELIVERY, 
    label: 'nav.createDelivery', 
    icon: PlusCircle,
  },
  { 
    path: ROUTE_PATHS.BRANCH_OFFICE, 
    label: 'nav.branchOffice', 
    icon: Building2,
    subItems: [
      { label: 'nav.overview', path: '/branch-office/overview', icon: LayoutDashboard },
      { label: 'nav.shipments', path: '/branch-office/shipments', icon: Package },
      { label: 'nav.team', path: '/branch-office/team', icon: Users },
      { label: 'nav.finance', path: '/branch-office/finance', icon: DollarSign },
    ]
  },
  { 
    path: ROUTE_PATHS.QR_CODE, 
    label: 'nav.qrCode', 
    icon: QrCode,
  },
  { 
    path: ROUTE_PATHS.ANALYTICS, 
    label: 'nav.analytics', 
    icon: BarChart3,
    subItems: [
      { label: 'nav.overview', path: '/analytics/overview', icon: BarChart3 },
      { label: 'nav.revenue', path: '/analytics/revenue', icon: DollarSign },
      { label: 'nav.drivers', path: '/analytics/drivers', icon: Truck },
    ]
  },
  { 
    path: ROUTE_PATHS.SETTINGS, 
    label: 'nav.settings', 
    icon: Settings,
  },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [expandedItems, setExpandedItems] = useState<string[]>([]);
  const { user, logout, canAccessPortal } = useAuth();
  const { language, setLanguage, t } = useLanguage();
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const toggleExpanded = (path: string) => {
    setExpandedItems(prev =>
      prev.includes(path)
        ? prev.filter(p => p !== path)
        : [...prev, path]
    );
  };

  const filteredNavItems = NAV_ITEMS.filter(item => canAccessPortal(item.path));

  return (
    <div className="min-h-screen bg-background">
      {/* Sidebar - Desktop */}
      <aside
        className={cn(
          "fixed left-0 top-0 z-40 h-screen bg-card border-r border-border transition-all duration-300 hidden lg:block",
          sidebarOpen ? "w-64" : "w-20"
        )}
      >
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="h-16 flex items-center justify-between px-4 border-b border-border">
            {sidebarOpen ? (
              <Link to={ROUTE_PATHS.DASHBOARD} className="flex items-center gap-2">
                <img src="/images/logo.png" alt="Britium Express" className="h-8" />
              </Link>
            ) : (
              <Link to={ROUTE_PATHS.DASHBOARD} className="flex items-center justify-center mx-auto">
                <img src="/images/logo.png" alt="Britium Express" className="h-8" />
              </Link>
            )}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className={cn(!sidebarOpen && "hidden")}
            >
              <ChevronRight className={cn("h-4 w-4 transition-transform", !sidebarOpen && "rotate-180")} />
            </Button>
          </div>

          {/* Navigation */}
          <ScrollArea className="flex-1 px-3 py-4">
            <nav className="space-y-1">
              {filteredNavItems.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path || location.pathname.startsWith(item.path + '/');
                const isExpanded = expandedItems.includes(item.path);
                const hasSubItems = item.subItems && item.subItems.length > 0;

                return (
                  <div key={item.path}>
                    <NavLink
                      to={item.path}
                      onClick={(e) => {
                        if (hasSubItems) {
                          e.preventDefault();
                          toggleExpanded(item.path);
                        }
                      }}
                      className={cn(
                        "flex items-center gap-3 px-3 py-2 rounded-lg transition-colors relative group",
                        isActive
                          ? "bg-primary text-primary-foreground"
                          : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                      )}
                    >
                      <Icon className="h-5 w-5 flex-shrink-0" />
                      {sidebarOpen && (
                        <>
                          <span className="flex-1 text-sm font-medium">{t(item.label)}</span>
                          {item.badge && (
                            <Badge variant="secondary" className="h-5 px-1.5 text-xs">
                              {item.badge}
                            </Badge>
                          )}
                          {hasSubItems && (
                            <ChevronRight
                              className={cn(
                                "h-4 w-4 transition-transform",
                                isExpanded && "rotate-90"
                              )}
                            />
                          )}
                        </>
                      )}
                      {!sidebarOpen && item.badge && (
                        <div className="absolute -top-1 -right-1 w-2 h-2 bg-destructive rounded-full" />
                      )}
                    </NavLink>

                    {/* Sub Items */}
                    {sidebarOpen && hasSubItems && isExpanded && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="ml-4 mt-1 space-y-1 border-l-2 border-border pl-4"
                      >
                        {item.subItems!.map((subItem) => {
                          const SubIcon = subItem.icon;
                          const isSubActive = location.pathname === subItem.path;
                          return (
                            <NavLink
                              key={subItem.path}
                              to={subItem.path}
                              className={cn(
                                "flex items-center gap-2 px-3 py-1.5 rounded-md text-sm transition-colors",
                                isSubActive
                                  ? "bg-accent text-accent-foreground font-medium"
                                  : "text-muted-foreground hover:bg-accent/50 hover:text-foreground"
                              )}
                            >
                              <SubIcon className="h-4 w-4" />
                              {t(subItem.label)}
                            </NavLink>
                          );
                        })}
                      </motion.div>
                    )}
                  </div>
                );
              })}
            </nav>
          </ScrollArea>

          {/* User Profile */}
          <div className="p-4 border-t border-border">
            {sidebarOpen ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-accent transition-colors">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <User className="h-4 w-4 text-primary" />
                    </div>
                    <div className="flex-1 text-left">
                      <p className="text-sm font-medium">{user?.name}</p>
                      <p className="text-xs text-muted-foreground capitalize">{user?.role}</p>
                    </div>
                    <ChevronDown className="h-4 w-4 text-muted-foreground" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>{t('common.myAccount')}</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => navigate(ROUTE_PATHS.SETTINGS)}>
                    <Settings className="mr-2 h-4 w-4" />
                    {t('nav.settings')}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="text-destructive">
                    <LogOut className="mr-2 h-4 w-4" />
                    {t('common.logout')}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button
                variant="ghost"
                size="icon"
                onClick={handleLogout}
                className="w-full"
              >
                <LogOut className="h-5 w-5" />
              </Button>
            )}
          </div>
        </div>
      </aside>

      {/* Mobile Sidebar */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40 lg:hidden"
              onClick={() => setMobileMenuOpen(false)}
            />
            <motion.aside
              initial={{ x: -300 }}
              animate={{ x: 0 }}
              exit={{ x: -300 }}
              className="fixed left-0 top-0 z-50 h-screen w-64 bg-card border-r border-border lg:hidden"
            >
              <div className="flex flex-col h-full">
                <div className="h-16 flex items-center justify-between px-4 border-b border-border">
                  <Link to={ROUTE_PATHS.DASHBOARD} className="flex items-center gap-2">
                    <img src="/images/logo.png" alt="Britium Express" className="h-8" />
                  </Link>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <X className="h-5 w-5" />
                  </Button>
                </div>

                <ScrollArea className="flex-1 px-3 py-4">
                  <nav className="space-y-1">
                    {filteredNavItems.map((item) => {
                      const Icon = item.icon;
                      const isActive = location.pathname === item.path;
                      return (
                        <NavLink
                          key={item.path}
                          to={item.path}
                          onClick={() => setMobileMenuOpen(false)}
                          className={cn(
                            "flex items-center gap-3 px-3 py-2 rounded-lg transition-colors",
                            isActive
                              ? "bg-primary text-primary-foreground"
                              : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                          )}
                        >
                          <Icon className="h-5 w-5" />
                          <span className="text-sm font-medium">{t(item.label)}</span>
                          {item.badge && (
                            <Badge variant="secondary" className="ml-auto">
                              {item.badge}
                            </Badge>
                          )}
                        </NavLink>
                      );
                    })}
                  </nav>
                </ScrollArea>

                <div className="p-4 border-t border-border">
                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-accent transition-colors text-destructive"
                  >
                    <LogOut className="h-5 w-5" />
                    <span className="text-sm font-medium">Logout</span>
                  </button>
                </div>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <div
        className={cn(
          "transition-all duration-300",
          sidebarOpen ? "lg:pl-64" : "lg:pl-20"
        )}
      >
        {/* Top Bar */}
        <header className="sticky top-0 z-30 h-16 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="flex h-full items-center justify-between px-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden"
            >
              <Menu className="h-5 w-5" />
            </Button>

            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="hidden lg:flex"
            >
              <Menu className="h-5 w-5" />
            </Button>

            <div className="flex items-center gap-2">
              {/* Language Toggle */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <Languages className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>{t('common.language')}</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem 
                    onClick={() => setLanguage('en')}
                    className={cn(language === 'en' && "bg-accent")}
                  >
                    {t('common.english')}
                  </DropdownMenuItem>
                  <DropdownMenuItem 
                    onClick={() => setLanguage('mm')}
                    className={cn(language === 'mm' && "bg-accent")}
                  >
                    {t('common.myanmar')}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-destructive rounded-full" />
              </Button>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="p-6">
          {children}
        </main>
      </div>
    </div>
  );
}